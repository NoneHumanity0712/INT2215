#ifndef UTILITIES_HPP
#define UTILITIES_HPP

#include "piece.hpp"

void swap(Piece &a, Piece &b);

#endif // UTILITIES_HPP